import rospy
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3
import tf
from four_wheel_steering_msgs.msg import FourWheelSteeringStamped
from std_msgs.msg import Header

class OdomEstimator:
    def __init__(self):
        # Set the wheelbase and wheel track of the robot (distance between the wheels)
        self.wheelbase = 2.8  # meters
        self.wheeltrack = 1.385  # meters

        # Initialize variables for the robot's position and orientation
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        # Create the odometry message and set its frame IDs
        self.odom = Odometry()
        self.odom.header.frame_id = "odom"
        self.odom.child_frame_id = "base_link"

        # Create a publisher to publish the odometry data
        self.odom_pub = rospy.Publisher("odom", Odometry, queue_size=50)

        # Create a subscriber to listen for the speed, front steering, and rear steering data
        rospy.Subscriber("four_wheel_steering", FourWheelSteeringStamped, self.data_callback)

    def data_callback(self, data):
        # Extract the current time and steering angles
        current_time = data.header.stamp
        fl_steering = data.data.front_steering_angle
        rl_steering = data.data.rear_steering_angle
        speed = data.data.speed
        # Calculate the time elapsed since the last update
        dt = (current_time - self.odom.header.stamp).to_sec()

        # Calculate the linear and angular velocity of the robot based on the speed and steering angles
        sin_theta = math.sin(self.theta)
        cos_theta = math.cos(self.theta)

        if fl_steering == 0 and rl_steering == 0:
            left_factor = right_factor = speed / self.wheelbase
        else:
            fl_factor = math.tan(fl_steering) / self.wheelbase
            rl_factor = math.tan(rl_steering) / self.wheelbase
            left_factor = (fl_factor - rl_factor) / 2.0
            right_factor = (fl_factor + rl_factor) / 2.0

        linear_velocity = speed * (left_factor + right_factor) / 2.0
        angular_velocity = speed * (left_factor - right_factor) / self.wheeltrack

        print(linear_velocity, angular_velocity)

        # Update the robot's position and orientation based on the linear and angular velocity
        self.x += linear_velocity * dt * cos_theta
        self.y += linear_velocity * dt * sin_theta
        self.theta += angular_velocity * dt
        # Create the quaternion for the robot's orientation
        odom_quat = Quaternion(*tf.transformations.quaternion_from_euler(0, 0, self.theta))

        # Fill in the odometry message with the current position, orientation, and velocity
        self.odom.header.stamp = current_time
        self.odom.pose.pose = Pose(Point(self.x, self.y, 0), odom_quat)
        self.odom.twist.twist = Twist(Vector3(linear_velocity, 0, 0), Vector3(0, 0, angular_velocity))

        # Publish the odometry message
        self.odom_pub.publish(self.odom)

if __name__ == '__main__':
    rospy.init_node('OdomEstimator', anonymous=True)
    odom_estimator = OdomEstimator()
    rospy.spin()
