g=12
print(bin(g)[2:].zfill(8))