#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH='/home/av-ipc/gen0_lidars/devel_isolated/sick_ldmrs_description:/home/av-ipc/gen0_ws/devel:/opt/ros/melodic:/home/av-ipc/gen0_lidars/install_isolated'
export LD_LIBRARY_PATH='/home/av-ipc/gen0_ws/devel/lib:/opt/ros/melodic/lib:/home/av-ipc/gen0_lidars/install_isolated/lib:/home/av-ipc/gen0_lidars/install_isolated/lib/x86_64-linux-gnu'
export PATH='/opt/ros/melodic/bin:/home/av-ipc/gen0_lidars/install_isolated/bin:/home/av-ipc/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
export PKG_CONFIG_PATH='/home/av-ipc/gen0_ws/devel/lib/pkgconfig:/opt/ros/melodic/lib/pkgconfig:/home/av-ipc/gen0_lidars/install_isolated/lib/pkgconfig:/home/av-ipc/gen0_lidars/install_isolated/lib/x86_64-linux-gnu/pkgconfig'
export PYTHONPATH='/home/av-ipc/gen0_ws/devel/lib/python2.7/dist-packages:/opt/ros/melodic/lib/python2.7/dist-packages:/home/av-ipc/gen0_lidars/install_isolated/lib/python2.7/dist-packages'
export ROSLISP_PACKAGE_DIRECTORIES="/home/av-ipc/gen0_lidars/devel_isolated/sick_ldmrs_description/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/av-ipc/gen0_lidars/src/sick_ldmrs_laser/sick_ldmrs_description:$ROS_PACKAGE_PATH"