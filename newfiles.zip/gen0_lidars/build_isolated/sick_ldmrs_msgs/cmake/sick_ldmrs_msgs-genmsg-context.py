# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/av-ipc/gen0_lidars/src/sick_ldmrs_laser/sick_ldmrs_msgs/msg/Object.msg;/home/av-ipc/gen0_lidars/src/sick_ldmrs_laser/sick_ldmrs_msgs/msg/ObjectArray.msg"
services_str = ""
pkg_name = "sick_ldmrs_msgs"
dependencies_str = "std_msgs;geometry_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "sick_ldmrs_msgs;/home/av-ipc/gen0_lidars/src/sick_ldmrs_laser/sick_ldmrs_msgs/msg;std_msgs;/opt/ros/melodic/share/std_msgs/cmake/../msg;geometry_msgs;/opt/ros/melodic/share/geometry_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/melodic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
