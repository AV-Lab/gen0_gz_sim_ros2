#!/usr/bin/env sh
# generated from catkin.builder Python module

/home/av-ipc/gen0_lidars/devel_isolated/sick_ldmrs_tools/env.sh "$@"
