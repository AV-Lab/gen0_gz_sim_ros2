
"use strict";

let Object = require('./Object.js');
let ObjectArray = require('./ObjectArray.js');

module.exports = {
  Object: Object,
  ObjectArray: ObjectArray,
};
