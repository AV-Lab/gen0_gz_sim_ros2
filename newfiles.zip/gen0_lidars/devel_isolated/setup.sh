#!/usr/bin/env sh
# generated from catkin.builder Python module

if [ ! -z "$_CATKIN_SETUP_DIR" ] && [ "$_CATKIN_SETUP_DIR" != "/home/av-ipc/gen0_lidars/devel_isolated" ]; then
  echo "Relocation of this workspace is not supported"
  return 1
fi

_CATKIN_SETUP_DIR= . "/home/av-ipc/gen0_lidars/devel_isolated/sick_ldmrs_tools/setup.sh"
